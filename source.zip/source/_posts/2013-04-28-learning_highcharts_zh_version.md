title: "Learning Highcharts中文教程"
date: 2013-04-08 22:53:41
update: 2015-05-10 00:36:33
tags:
  - Highcharts
categories:
  - Learning
  - Learning Highcharts
---

# 科技零售(RetailSCM.com) Learning Highcharts中文教程

_<span style="color: #808080;">版權保留，網路轉載請註明來源，謝絕紙質媒體轉載，謝謝。</span>_

經過一段時間的比對及篩選，已經選擇了Highcharts作為RetailSCM未來的圖表工具。

因為目前市面上並沒有比較有整體性的Highcharts中文教程，於是有了整理RetailSCM Highcharts系列中文教程的想法，本教程精選Learning Highcharts書中的章節進行翻譯，再視狀況輔以API進行說明。

因Paul工作繁重，閒暇之餘甚少，教程中可能會出現疏漏或錯誤，望發現錯誤時及時與Paul溝通，以便進行修訂，避免影響更多讀者。

感謝Joe Kuan可以給我們帶來一本完整的Highcharts基礎教程。