title: "第一章 網頁圖表"
date: 2015-05-10 00:27:13
update: 2015-05-10 00:36:33
tags:
  - Highcharts
categories:
  - Learning
  - Learning Highcharts
  - Web Charts
---
# 科技零售(RetailSCM.com) Learning Highcharts中文教程

_<span style="color: #808080;">版權保留，網路轉載請註明來源，謝絕紙質媒體轉載，謝謝。</span>_

第一章，網頁圖表，介紹了web圖表的發展歷程，從HTML到最新的HTML5 SVG標準和canvas技術。本章對比了市面上使用的HTML 5標準的圖表庫，以說明Highcharts為什麼是更優秀的產品。

[網頁圖表的發展歷史](/Learning/Learning-Highcharts/Web-Charts/a-short-history-of-web-charting/ "01.網頁圖表的發展歷史")

[Javascript和HTML的崛起](/Learning/Learning-Highcharts/Web-Charts/the-uprising-of-javascript-and-html5/ "02.JavaScript和HTML5的崛起")

[目前主流的Javascript圖表](/Learning/Learning-Highcharts/Web-Charts/javascript-charts-on-the-marke/ "03.目前主流的Javascript圖表")

[為什麼選擇Highcharts](/Learning/Learning-Highcharts/Web-Charts/why-highcharts/ "04.為什麼選擇Highcharts")

[快速入門手冊](/Learning/Learning-Highcharts/Web-Charts/highcharts-a-quick-tutorial/ "05.快速入門手冊")