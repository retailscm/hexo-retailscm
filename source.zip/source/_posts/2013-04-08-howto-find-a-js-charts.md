title: "如何選擇一款主流的JS圖表工具(JS Charts)"
date: 2013-04-08 00:50:38
tags:
categories:
  - WEB2.0
  - jQuery
---

選擇圖表工具對我來說有一個前提，就是要漂亮。

本著不漂亮毋寧死的精神去找了很久，主要鎖定了3款，分別是highcharts, amcharts, fusioncharts（抱歉，對我來說jqchart還不算最漂亮，可以勉強做個backup啦，畢竟免費）

但是選擇產品是一個很重要的決定，已經花了時間和精力投入下去之後，是希望它是一個主流的，生命力持久的產品，這樣投資報酬率才比較好，但是好像並沒有比較不錯的推薦，怎麼選擇呢？我想到了Google Trend，上去看一下，果然……很容易就得到了心中的答案，直接上圖吧

[![highcharts vs  amcharts vs fusioncharts](/images/post/highcharts-vs-amcharts-vs-fusioncharts.jpg)](/images/post/highcharts-vs-amcharts-vs-fusioncharts.jpg)



搜索的地區，amcharts主要集中在美國，fusioncharts主要集中在中國，highcharts則分佈比較廣泛，美國，加拿大，中國，印度，歐洲一些國家也都有使用。

並且從2009年末highcharts出現之後，一整個異軍突起的表現，令人值得讚嘆及肯定。

[![2004 to 2013 trend](/images/post/2004-to-2013-trend.jpg)](/images/post/2004-to-2013-trend.jpg)