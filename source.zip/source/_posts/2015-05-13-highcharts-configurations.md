title: "第二章 Highcharts配置"
date: 2015-05-13 19:36:33
update: 2015-05-13 19:36:33
tags:
  - Highcharts
categories:
  - Learning
  - Learning Highcharts
  - Highcharts configurations
---

# 科技零售(RetailSCM.com) Learning Highcharts中文教程

_<span style="color: #808080;">版權保留，網路轉載請註明來源，謝絕紙質媒體轉載，謝謝。</span>_

第二章 Highcharts配置，涵蓋了常用的配置選項，包括示例，並介紹了圖表佈局（chart layout）是如何工作的。


[配置選項](/Learning/Learning-Highcharts/Highcharts-configurations/configuration-structure/ "01.配置選項")

[了解圖表佈局(layout)](/Learning/Learning-Highcharts/Highcharts-configurations/understanding-highcharts-layouts/ "02.了解圖表佈局(layout)")

[軸在圖表中的應用](/Learning/Learning-Highcharts/Highcharts-configurations/framing-the-chart-with-axes/ "03.軸在圖表中的應用")

[重溫series的配置](/Learning/Learning-Highcharts/Highcharts-configurations/revisiting-the-series-configuration/ "04.重溫series配置")

[探索PlotOptions](/Learning/Learning-Highcharts/Highcharts-configurations/exploring-plotoptions/ "05.探索PlotOptions")

[提示框的樣式](/Learning/Learning-Highcharts/Highcharts-configurations/styling-the-tooltips/ "06.提示框的樣式")

[動態圖表](/Learning/Learning-Highcharts/Highcharts-configurations/animating-charts/ "07.動態圖表")

[擴展色彩漸變(colors with gradients)](/Learning/Learning-Highcharts/Highcharts-configurations/expanding-colors-with-gradients/ "08.擴展色彩漸變(colors with gradients)")